export const scaleFactor = 4;

export const dialogueData = {
  pc: `This is my PC. I work mostly in Python these days, but I'm currently learning JavaScript and Java. 
    I've made a couple of games in Python. Regardless of the language, I just love programming. 
    Here is my <a href="https://github.com/Lobochild" target="_blank">Github</a>!`,
  
  "cs-degree": `This is my Industrial Design degree. It's a bit out of the ordinary for an IT professional, right? 
    I keep it on the wall because it reminds me that a strong foundation in design can lead to innovative tech solutions. Plus, it was a tough journey worth remembering!`,

  "sofa-table": `That's my sofa. It's not just for relaxing; it's my thinking spot where many of my best programming ideas come to life. 
    Sometimes I pretend to be a programming guru giving a Ted Talk to an invisible audience!`,

  tv: `That's my TV. When I'm not coding, I love binge-watching series and movies. It's a great way to unwind and get some inspiration for my next project!`,

  bed: `This is where I sleep and dream. The bed is a magical place where the best ideas come to life just as I'm about to drift off. 
    I often jump out of bed to jot down a brilliant thought, hoping it leads to the next big thing in tech.`,

  resume: `This is my desk and on it is my CV. <a href="https://github.com/Lobochild/Curriculum/blob/main/cv_gabriel.lobato.EN.pdf" target="_blank">Check it out?</a>
    Contact me at gabri_82@hotmail.com if you have any interesting job opportunities!`,

  projects: `Info about this portfolio: It's made with the Kaboom.js library, a great tool for creating games in JavaScript.
    The text you're reading is rendered with HTML/CSS. So, the textbox you're currently reading is not rendered within canvas.`,

  library: `There are a lot of books on my shelves, ranging from technical manuals to history books (which I love), 
    science fiction, historical novels, adventure stories, and classic literature. I might have a slight book hoarding problem!`,

  exit: `If you want to exit Lobochild's portfolio, just close the tab.`
};

